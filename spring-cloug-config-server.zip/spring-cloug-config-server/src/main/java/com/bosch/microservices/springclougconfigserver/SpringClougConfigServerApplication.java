package com.bosch.microservices.springclougconfigserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringClougConfigServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringClougConfigServerApplication.class, args);
	}

}
